<?php
// Memanggil file koneksi.php
include_once("../koneksi.php");

// Syntax untuk mengambil semua data dari table mahasiswa
$result = mysqli_query($con, "SELECT * FROM mustahik");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Utama</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Custom CSS for row colors -->
    <style>
        /* Define custom classes for row colors */
        .even-row {
            background-color: #f2f2f2; /* Light gray background for even rows */
        }

        .odd-row {
            background-color: #ffffff; /* White background for odd rows */
        }
    </style>
</head>

<body>

<!-- navbar -->
<div>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="#">
          <i class="fas fa-mosque"></i> <!-- Ikon masjid -->
          <b>ZAKAT MASJID NURUL HUDA</b>
        </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#"> / Mustahik / Lihat</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
    <br><br>
    <div class="container mt-4">
        <a href="cetakmustahik.php" class="btn btn-dark "><strong>Cetak Semua Data</strong></a>
        <a href="createmustahik.php" class="btn btn-primary "><strong>Tambah Data Baru</strong></a>
        <a href="Mustahik.php" class="btn btn-success "><strong>Kembali Home mustahik</strong></a>
        <a href="pembagian.php" class="btn btn-info "><strong>Filter Berdasarkan Jalur</strong></a>
        
        <br><br>
        <table class="table table-bordered w-100 text-center">
            <thead>
                <tr class="bg-primary text-white">
                    <th>Id Mustahik</th>
                    <th>Nama Mustahik</th>
                    <th>Jumlah</th>
                    <th>Jalur</th>
                    <th>Kelola Data</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $row_number = 0; // Initialize row number variable
                while ($user_data = mysqli_fetch_array($result)) {
                    // Alternate row colors
                    $row_class = ($row_number % 2 == 0) ? 'even-row' : 'odd-row';
                    echo "<tr class='$row_class'>";
                    echo "<td>" . $user_data['Id_mustahik'] . "</td>";
                    echo "<td>" . $user_data['nama'] . "</td>";
                    echo "<td>" . $user_data['jumlah'] . "</td>";
                    echo "<td>" . $user_data['jalur'] . "</td>";
                    echo "<td><a href='updatemustahik.php?id=$user_data[Id_mustahik]' class='btn btn-primary'>Update</a> <a href='deletemustahik.php?id=$user_data[Id_mustahik]' class='btn btn-danger'>Delete</a></td></tr>";
                    $row_number++; // Increment row number
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Include Bootstrap JS and jQuery (optional) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
