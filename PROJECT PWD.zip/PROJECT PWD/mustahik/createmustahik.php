<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah data Mustahik</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.15/dist/tailwind.min.css" rel="stylesheet">
</head>

<body>

    <div>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="#">
          <i class="fas fa-mosque"></i> <!-- Ikon masjid -->
          <b>ZAKAT MASJID NURUL HUDA</b>
        </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#"> / Mustahik Zakat / catat Mustahik</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>

    <div class="container">
      <br>
      <div class="card card-header border-primary">
        <h2 class="mt-4 text-center "><strong>Tambah Data Musathik</strong></h2>
        <form action="createmustahik.php" method="post" name="form1">
            <div class="form-group">
                <label for="id">ID:</label>
                <!-- <input type="number" class="form-control" id="id_amil" name="id_amil" required> -->
                <input type="text" class="form-control" name="id" value="auto" id="id">
            </div>

            <div class="form-group">
                <label for="nama">Nama:</label>
                <input type="text" class="form-control" id="nama" name="nama" required>
            </div>

            <div class="form-group">
                <label for="tugas">jumlah:</label>
                <input type="text" class="form-control" id="jumlah" name="jumlah" required>
            </div>

           <div class="form-group">
                <label for="jenis_zakat">Jalur Mustahik:</label>
                <!-- <input type="option" class="form-control" id="jenis_zakat" name="jenis_zakat" required> -->
                <select class="form-control" id="jalur" name="jalur" required>
                    <option >  Jalur penerima  </option>
                    <option value="Jalur Tengah ">Jalur Tengah</option>
                    <option value="Jalur Selatan ">Jalur Selatan</option>
                    <option value="Jalur Utara ">Jalur Utara</option>
                </select>
          </div>

            <button type="submit" class="btn btn-success w-100" name="Submit"><strong>Tambah</strong></button>
            <br><br>
            <a href="Mustahik.php" class="btn btn-primary w-100"><strong>Kembali Home Mustahik</strong></a>
            <br><br>
        </form>
      </dev>
    </div>
</body>
</html>

<?php
// Memanggil file koneksi.php
include('../koneksi.php');

// Perkondisian untuk mengecek apakah tombol submit sudah ditekan.
if (isset($_POST['Submit'])) {
    $id = isset($_POST['id_mustahik']) && !empty($_POST['id_mustahik']) && $_POST['id_mustahik'] != 'auto' ? $_POST['id_mustahik'] : NULL;
    $nama = strtoupper($_POST['nama']); // Mengonversi nama menjadi huruf kapital.
    $jumlah = strtoupper($_POST['jumlah']); // Mengonversi tugas menjadi huruf kapital.
    $jalur = strtoupper($_POST['jalur']); // Mengonversi tugas menjadi huruf kapital.

    // Syntax untuk menambahkan data ke table amilzakat
    $result = mysqli_query($con, "INSERT INTO mustahik(id_mustahik, nama, jumlah, jalur ) VALUES('$id', '$nama', '$jumlah','$jalur')");

    // Menampilkan pesan jika data berhasil disimpan.
    echo '<br><br><div class="container">';
    echo '<div class="alert alert-success text-center">';
    echo "Data berhasil disimpan. <a href='readmustahik.php'><strong>LIHAT DATA</strong></a>";
    echo '</div>';
    echo '</div>';
}


?>