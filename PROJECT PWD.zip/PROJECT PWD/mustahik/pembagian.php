<?php
// Memanggil file koneksi.php
include_once("../koneksi.php");

// Syntax untuk mengambil semua data dari table mahasiswa

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Utama</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Custom CSS for row colors -->
    <style>
        /* Define custom classes for row colors */
        .even-row {
            background-color: #f2f2f2; /* Light gray background for even rows */
        }

        .odd-row {
            background-color: #ffffff; /* White background for odd rows */
        }
    </style>
</head>

<body>

<!-- navbar -->
<div>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="#">
          <i class="fas fa-mosque"></i> <!-- Ikon masjid -->
          <b>ZAKAT MASJID NURUL HUDA</b>
        </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#"> / Mustahik / Lihat</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
    <br>
    <div class="container mt-4">
        <form id="jalurForm" action="" method="post">
            <div class="form-group">
                <label for="jalur"><strong>Mustahik:</strong></label>
                <select class="form-control" id="jalur" name="jalur" required onchange="submitForm()">
                    <option value="">Jalur penerima</option>
                    <option value="Jalur Tengah">JALUR TENGAH</option>
                    <option value="Jalur Selatan">JALUR SELATAN</option>
                    <option value="Jalur Utara">JALUR UTARA</option>
                </select>
            </div>
    <!-- Formulir dan opsi jalur di sini -->
    </form>
    <div class="container mt-4">
    <?php
        // Ambil nilai jalur dari formulir jika sudah dipilih
        $selectedJalur = isset($_POST['jalur']) ? $_POST['jalur'] : '';

        echo "<div class='container mt-4'>";
        echo "<h4><strong class='text-center'>Daftar Penerima Zakat Jalur: $selectedJalur</strong></h4>";

        // ... (Continue with the rest of your HTML and PHP code)
    ?>
    <table class="table table-bordered w-100 text-center mt-4">
        <thead>
            <tr class="bg-primary text-white">
                <th>Id Mustahik</th>
                <th>Nama Mustahik</th>
                <th>Jumlah</th>
                <th>Jalur</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Ubah query SQL berdasarkan pilihan jalur
            $result = mysqli_query($con, "SELECT * FROM mustahik WHERE jalur = '$selectedJalur'");

            $row_number = 0; // Initialize row number variable
            while ($user_data = mysqli_fetch_array($result)) {
                // Alternate row colors
                echo "<tr>";
                echo "<td>" . $user_data['Id_mustahik'] . "</td>";
                echo "<td>" . $user_data['nama'] . "</td>";
                echo "<td>" . $user_data['jumlah'] . "</td>";
                echo "<td>" . $user_data['jalur'] . "</td>";
                $row_number++; // Increment row number
            }
            ?>
        </tbody>
    </table>

    <a href="cetakmustahik.php" class="btn btn-success border-success w-100"><strong>CETAK DATA</strong></a><br>
</div>


    <script>
        // Fungsi untuk mengirim formulir saat opsi jalur berubah
        function submitForm() {
            document.getElementById("jalurForm").submit();
        }
    </script>
    </div>
   

    <!-- Include Bootstrap JS and jQuery (optional) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>

