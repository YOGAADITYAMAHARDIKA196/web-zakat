<?php
require('../fpdf/fpdf.php');
include '../koneksi.php';

class PDF extends FPDF
{
    function Header()
    {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(190, 7, 'DAFTAR PEMBAGIAN ZAKAT FITRAH MASJID NURUL HUDA', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(190, 7, 'LEMBAGA MIKRO PENGELOLAAN ZAKAT MASJID NURUL HUDA', 0, 1, 'C');
        $this->Cell(10, 7, '', 0, 1);
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(30, 6, 'ID MUSTAHIQ', 1, 0);
        $this->Cell(70, 6, 'NAMA MUSTAHIQ', 1, 0);
        $this->Cell(20, 6, 'JUMLAH', 1, 0);
        $this->Cell(50, 6, 'JALUR', 1, 1);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
    }

    function ChapterBody($data)
    {
        $this->SetFont('Arial', '', 10);
        foreach ($data as $row) {
            $this->Cell(30, 6, $row['Id_mustahik'], 1, 0);
            $this->Cell(70, 6, $row['nama'], 1, 0);
            $this->Cell(20, 6, $row['jumlah'], 1, 0);
            $this->Cell(50, 6, $row['jalur'], 1, 1);
        }
    }
}

$pdf = new PDF();
$pdf->AddPage();

// Fetch data from the database
$result_mustahik = mysqli_query($con, "SELECT * FROM mustahik");
$data_mustahik = array();

while ($row = mysqli_fetch_array($result_mustahik)) {
    $data_mustahik[] = $row;
}

$pdf->ChapterBody($data_mustahik);

$pdf->Output();
?>
