<?php
// Memanggil file koneksi.php
include_once("../koneksi.php");

// Perkondisian untuk mengecek apakah tombol submit sudah ditekan.
if (isset($_POST['update'])) {
    $id = $_POST['id_mustahik'];
    $nama = $_POST['nama'];
    $jumlah = $_POST['jumlah'];
    $jalur = $_POST['jalur'];

    // Syntax untuk mengupdate data user berdasarkan id
    $result = mysqli_query($con, "UPDATE mustahik SET nama = '$nama', jumlah='$jumlah',jalur='$jalur' where id_mustahik ='$id'");

    // Redirect ke readamil.php
    header("Location:readmustahik.php");
}
?>


<?php
// Mengambil id dari url
// jangan di ganti jika tidak ingin error
$id = $_GET['id'];

// Syntax untuk mengambil data berdasarkan id
$result = mysqli_query($con, "SELECT * FROM mustahik WHERE id_mustahik='$id'");
while ($user_data = mysqli_fetch_array($result)) {
    $nama = $user_data['nama'];
    $jumlah= $user_data['jumlah'];
    $jalur= $user_data['jalur'];
}
?>


<!DOCTYPE html>
<html>

<head>
    <title>Edit Data Mustahik</title>
    <!-- Include Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.15/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
</head>
<body>
<div>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="#">
          <i class="fas fa-mosque"></i> <!-- Ikon masjid -->
          <b>ZAKAT MASJID NURUL HUDA</b>
        </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#"> / Mustahik / Lihat / Update</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
</body>
<body class="bg-gray-100">
<!-- navbar -->
    <br><br>
    <div class="container mx-auto p-4">
        <a href="readmustahik.php" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded inline-block mb-4">Home Data</a>
        <form name="updatemustahik" method="post" action="updatemustahik.php">
            <div class="bg-white p-4 rounded shadow">

                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="nama">Nama</label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" name="nama" value='<?php echo $nama; ?>'>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="jumlah">Jumlah</label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" name="jumlah" value='<?php echo $jumlah; ?>'>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="jalur">Jalur</label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" name="jalur" value='<?php echo $jalur; ?>'>
                    <select class="form-control" id="jalur" name="jalur" required>
                        <option >  Jalur penerima  </option>
                        <option value="Jalur Tengah ">JALUR TENGAH</option>
                        <option value="Jalur Selatan ">JALUR SELATAN</option>
                        <option value="Jalur Utara ">JALUR UTARA</option>
                    </select>
                </div>
                <input type="hidden" name="id_mustahik" value='<?php echo $id ?>'>
                <button class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full" type="submit" name="update">Update Sekarang</button><br>
            </div>
        </form>
    </div>
</body>

</html>
