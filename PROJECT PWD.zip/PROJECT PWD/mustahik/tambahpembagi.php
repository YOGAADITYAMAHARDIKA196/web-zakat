<?php
include_once("../koneksi.php");

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // Get the values from the form
    $id_amil = $_POST['id_amil'];
    $selectedJalur = isset($_POST['jalur']) ? $_POST['jalur'][0] : null;

    // Get the name of the pembagi from the amil table
    $query_amil = "SELECT nama FROM amilzakat WHERE id_amil = $id_amil";
    $result_amil = mysqli_query($con, $query_amil);

    if ($result_amil) {
        $amil_data = mysqli_fetch_array($result_amil);
        $nama_pembagi = $amil_data['nama'];

        // Insert data into the pembagian table
        $query_insert = "INSERT INTO pembagian (nama, jalur, id_amil) VALUES ('$nama_pembagi', '$selectedJalur', $id_amil)";
        $result_insert = mysqli_query($con, $query_insert);

        if ($result_insert) {
            echo "Data berhasil ditambahkan ke tabel pembagian.";
        } else {
            echo "Gagal menambahkan data ke tabel pembagian: " . mysqli_error($con);
        }
    } else {
        echo "Gagal mengambil data amil: " . mysqli_error($con);
    }
}
?>
