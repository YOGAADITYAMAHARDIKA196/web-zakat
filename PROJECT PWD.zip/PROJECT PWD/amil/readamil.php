<?php
// Memanggil file koneksi.php
include_once("../koneksi.php");

// Syntax untuk mengambil semua data dari tabel amilzakat
$result = mysqli_query($con, "SELECT * FROM amilzakat");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Utama</title>
    <!-- Sertakan Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Gaya kustom untuk warna baris -->
    <style>
        /* Tentukan kelas kustom untuk warna baris */
        .even-row {
            background-color: #f2f2f2; /* Warna abu-abu muda untuk baris genap */
        }

        .odd-row {
            background-color: #ffffff; /* Warna putih untuk baris ganjil */
        }
    </style>
</head>

<body>

<!-- Navbar -->
<div>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="#">
          <i class="fas fa-mosque"></i> <!-- Ikon masjid -->
          <b>ZAKAT MASJID NURUL HUDA</b>
        </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="../index.php">Beranda</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="Amil.php">Beranda Amil</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="readamil.php">Lihat Data</a>
              </li>
              
            </ul>
          </div>
        </div>
      </nav>
    </div>
    <br><br>
    <div class="container mt-4">
        <a href="createamil.php" class="btn btn-primary "><strong>Tambah Data Baru</strong></a>
        <a href="Amil.php" class="btn btn-success "><strong>Kembali ke Beranda Amil</strong></a>
        <a href="CetakAmil.php" class="btn btn-info text-white"><strong>Cetak Semua Data Amil ke pdf</strong></a>
        <!-- Awal form pencarian -->
        <br><br>
        <form action="readamil.php" method="post" name="form1">
            <div class="form-group">
                <input type="text" class="form-control" id="nama" name="nama" required> <br>
                <button type="search" class="btn btn-secondary text-white w-100" name="Search"><strong>Cari Data</strong></button>
            </div>

      </form>
        <!-- Akhir form pencarian -->
        <?php
          if (isset($_POST['Search'])) {
              $cari_nama = $_POST['nama'];

              // Syntax untuk melakukan pencarian data berdasarkan NIM
              $query = "SELECT * FROM amilzakat WHERE nama LIKE '%$cari_nama%'";
              $result = mysqli_query($con, $query);

              if (mysqli_num_rows($result) > 0) {
                  echo "<table class='table table-bordered'>";
                  echo "<thead><tr class='bg-primary text-white'><th>ID AMIL</th><th>NAMA</th><th>TUGAS</th></tr></thead>";
                  echo "<tbody>";

                  while ($row = mysqli_fetch_assoc($result)) {
                      echo '<div class="container">';
                      echo "<td>" . $row['id_amil'] . "</td>";
                      echo "<td>" . $row['nama'] . "</td>";
                      echo "<td>" . $row['tugas'] . "</td>";
                      echo "</tr>";
                      echo '</div>';
                  }

                  echo "</tbody>";
                  echo "</table>";

                  // Tambahkan input tersembunyi untuk menyimpan flag JS bahwa pencarian berhasil
                  echo '<input type="hidden" id="searchSuccess" value="1">';
              } else {
                  echo '<br>';
                  echo '<div class="container">';
                  echo '<div class="alert alert-danger text-center">';
                  echo '<strong>Data Tidak Ditemukan</strong>';
                  echo '</div>';
                  echo '</div>';
              }
          }
          ?>
  <script>
    // Periksa apakah pencarian berhasil menggunakan input tersembunyi
    if (document.getElementById('searchSuccess') && document.getElementById('searchSuccess').value === '1') {
        // Tampilkan bagian hasil pencarian
        document.getElementById('searchResults').style.display = 'block';
    } else {
        // Sembunyikan tabel jika tidak ada hasil pencarian
        document.getElementById('searchResults').style.display = 'none';
    }
</script>
<?php
if (!isset($_POST['Search'])) {
    // Hanya tampilkan tabel data umum jika tidak ada pencarian yang dilakukan
    echo '<table class="table table-bordered w-100 text-center">';
    echo '<thead>';
    echo '<tr class="bg-primary text-white">';
    echo '<th>ID AMIL</th>';
    echo '<th>Nama Amil</th>';
    echo '<th>Tugas</th>';
    echo '<th>Kelola Data</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';

    $row_number = 0; // Inisialisasi variabel nomor baris
    while ($user_data = mysqli_fetch_array($result)) {
        // Ganti warna baris secara bergantian
        $row_class = ($row_number % 2 == 0) ? 'even-row' : 'odd-row';
        echo "<tr class='$row_class'>";
        echo "<td>" . $user_data['id_amil'] . "</td>";
        echo "<td>" . $user_data['nama'] . "</td>";
        echo "<td>" . $user_data['tugas'] . "</td>";
        echo "<td><a href='updateamil.php?id=$user_data[id_amil]' class='btn btn-primary'>Update</a> <a href='deleteamil.php?id=$user_data[id_amil]' class='btn btn-danger'>Hapus</a></td></tr>";
        $row_number++; // Tingkatkan nomor baris
    }

    echo '</tbody>';
    echo '</table>';
}
?>
    </div>

    <!-- Sertakan Bootstrap JS dan jQuery (opsional) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script