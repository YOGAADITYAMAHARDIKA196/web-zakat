<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah data Amil</title>
    <!-- Include Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.15/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>

    <div>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <i class="fas fa-mosque"></i> <!-- Ikon masjid -->
                    <b>ZAKAT MASJID NURUL HUDA</b>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="../index.php"> Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="Amil.php"> Amil Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="createamil."> Catat Amil</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>

    <div class="container">
        <br>
        <div class="card card-header border-primary">
            <h2 class="mt-4 text-center "><strong>Tambah Data Amil Zakat</strong></h2>
            <form action="createamil.php" method="post" name="form1" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="id">ID:</label>
                <!-- <input type="number" class="form-control" id="id_amil" name="id_amil" required> -->
                <input type="text" class="form-control" name="id" value="auto" id="id">
            </div>

            <div class="form-group">
                <label for="nama">Nama:</label>
                <input type="text" class="form-control" id="nama" name="nama" required>
            </div>

            <div class="form-group">
                <label for="jenis_zakat">Jalur Mustahik:</label>
                <!-- <input type="option" class="form-control" id="jenis_zakat" name="jenis_zakat" required> -->
                <select class="form-control" id="tugas" name="tugas" required>
                    <option >  TUGAS AMIL  </option>
                    <option value="Admin Note ">Admin Note</option>
                    <option value="Perlengkapan">Perlengkapan</option>
                    <option value="Pembagi ">Pembagi</option>
                    <option value="Penimbang">Penimbang</option>
                    <option value="Konsumsi">Konsumsi</option>
                </select>
            </div>

            <button type="submit" class="btn btn-success w-100" name="Submit"><strong>Tambah</strong></button>
            <br><br>
            <a href="Amil.php" class="btn btn-primary w-100"><strong>Kembali Home Amil</strong></a>
            <br><br>
        </form>
        </div>
    </div>

</body>

</html>

<?php
// Memanggil file koneksi.php
include('../koneksi.php');

// Perkondisian untuk mengecek apakah tombol submit sudah ditekan.
if (isset($_POST['Submit'])) {
    $id = isset($_POST['id_amil']) && !empty($_POST['id_amil']) && $_POST['id_amil'] != 'auto' ? $_POST['id_amil'] : NULL;
    $nama = strtoupper($_POST['nama']); 
    $tugas = strtoupper($_POST['tugas']); 
    $result = mysqli_query($con,"SELECT COUNT(*) as count FROM amilzakat WHERE nama = '$nama'");

    if ($result) {
        $row = $result->fetch_assoc();
        $count = $row['count'];

        // Jika nama sudah ada, tampilkan pesan error
        if ($count > 0) {
            echo '<br><br><div class="container">';
            echo '<div class="alert alert-danger text-center">';
            echo "Error: Nama sudah ada dalam database. Tidak bisa menambahkan data.";
            echo '</div>';
            echo '</div>';
        } else {
            // Jika nama belum ada, lakukan operasi INSERT
            $result = mysqli_query($con, "INSERT INTO amilzakat(id_amil, nama, tugas) VALUES('$id', '$nama', '$tugas')");

            // Menampilkan pesan jika data berhasil disimpan.
            echo '<br><br><div class="container">';
            echo '<div class="alert alert-success text-center">';
            echo "Data berhasil disimpan. <a href='readamil.php'><strong>LIHAT DATA</strong></a>";
            echo '</div>';
            echo '</div>';
        }
    }
}
?>

<script>
    function validateForm() {
        var namaInput = document.getElementById("nama");
        var namaTugas = document.getElementById("tugas");
 
        var namaPattern = /^[A-Za-z\s]+$/; 
        var tugasPattern = /^[A-Za-z\s]+$/;  

        // Validate Nama
        if (!namaPattern.test(namaInput.value)) {
            alert("Nama harus berupa huruf, tidak boleh angka.");
            namaInput.focus();
            return false;
        }

        // Validate tugas
        if (!tugasPattern.test(namaTugas.value)) {
            alert("Tugas harus berupa huruf, tidak boleh angka.");
            namaTugas.focus();
            return false;
        }
        return true; // Submit the form if both validations pass
    }
</script>
