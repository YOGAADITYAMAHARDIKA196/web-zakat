<?php
// Memanggil file koneksi.php
include_once("../koneksi.php");

// Perkondisian untuk mengecek apakah tombol submit sudah ditekan.
if (isset($_POST['update'])) {
    $id = $_POST['id_amil'];
    $nama = strtoupper($_POST['nama']); 
    $tugas = strtoupper($_POST['tugas']);

    // Syntax untuk mengupdate data user berdasarkan id
    $result = mysqli_query($con, "UPDATE amilzakat SET nama = '$nama', tugas='$tugas' where id_amil ='$id'");

    // Redirect ke readamil.php
    header("Location:readamil.php");
}
?>
<?php
// Mengambil id dari url
// jangan di ganti jika tidak ingin error
$id = $_GET['id'];

// Syntax untuk mengambil data berdasarkan id
$result = mysqli_query($con, "SELECT * FROM amilzakat WHERE id_amil='$id'");
while ($user_data = mysqli_fetch_array($result)) {
    $nama = $user_data['nama'];
    $tugas = $user_data['tugas'];
}
?>


<!DOCTYPE html>
<html>

<head>
    <title>Edit Data Amil Zakat</title>
    <!-- Include Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.15/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
</head>
<body>
<div>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="#">
          <i class="fas fa-mosque"></i> <!-- Ikon masjid -->
          <b>ZAKAT MASJID NURUL HUDA</b>
        </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#"> / Amil Zakat / Lihat / Update</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
</body>
<body class="bg-gray-100">
<!-- navbar -->
    <br><br>
    <div class="container mx-auto p-4">
        <a href="readamil.php" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded inline-block mb-4">Home Data</a>
        <form name="updateamilzakat" method="post" action="updateamil.php">
            <div class="bg-white p-4 rounded shadow">

                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="nama">Nama</label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" name="nama" value='<?php echo $nama; ?>'>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="jalur">Tugas</label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" name="tugas" value='<?php echo $tugas; ?>'>
                    <select class="form-control" id="tugas" name="tugas" required>
                      <option value="" disabled selected class="text-gray-500">TUGAS AMIL</option>
                      <option value="Admin Note">Admin Note</option>
                      <option value="Perlengkapan">Perlengkapan</option>
                      <option value="Pembagi">Pembagi</option>
                      <option value="Penimbang">Penimbang</option>
                      <option value="Konsumsi">Konsumsi</option>
                    </select>
                </div>
                <input type="hidden" name="id_amil" value='<?php echo $id ?>'>
                <button class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full" type="submit" name="update">Update</button>
            </div>
        </form>
    </div>
</body>

</html>
