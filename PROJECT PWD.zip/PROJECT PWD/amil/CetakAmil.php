<?php
// Memanggil file koneksi.php
include_once("../koneksi.php");

require('../fpdf/fpdf.php'); // Pastikan path ini sesuai dengan lokasi FPDF di proyek Anda

class PDF extends FPDF
{
    function Header()
    {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(190, 7, 'DAFTAR NAMA AMIL ZAKAT FITRAH MASJID NURUL HUDA', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(190, 7, 'LEMBAGA MIKRO PENGELOLAAN ZAKAT MASJID NURUL HUDA', 0, 1, 'C');
        $this->Cell(10, 7, '', 0, 1);
        $this->SetFont('Arial', 'B', 10);

        // Header tabel
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(30, 7, 'ID AMIL', 1, 0, 'C');
        $this->Cell(95, 7, 'NAMA', 1, 0, 'C');
        $this->Cell(55, 7, 'TUGAS', 1, 0, 'C');
        $this->Ln();
    }

    function Footer()
    {
        // Tampilkan nomor halaman di bagian bawah dokumen
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Halaman ' . $this->PageNo(), 0, 0, 'C');
    }
}

// Membuat objek PDF
$pdf = new PDF();
$pdf->AddPage();

// Mengambil data dari tabel amilzakat
$result = mysqli_query($con, "SELECT id_amil, nama, tugas FROM amilzakat");

// Menampilkan data dalam tabel PDF
$pdf->SetFont('Arial', '', 10);
while ($row = mysqli_fetch_assoc($result)) {
    $pdf->Cell(30, 7, $row['id_amil'], 1, 0, 'C'); 
    $pdf->Cell(95, 7, $row['nama'], 1, 0, 'C'); 
    $pdf->Cell(55, 7, $row['tugas'], 1, 0, 'C'); 
    $pdf->Ln();
}

// Set nama file untuk diunduh
header('Content-Disposition: attachment; filename="Data Amil cetak.pdf"');

// Menyimpan atau menampilkan hasil PDF
$pdf->Output();
?>
