<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah data Muzaki</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>

    <div>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="#">
          <i class="fas fa-mosque"></i> <!-- Ikon masjid -->
          <b>ZAKAT MASJID NURUL HUDA</b>
        </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#"> /  Muzaki  / catat muzaki</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>

    <div class="container">
        <h2 class="mt-4 text-center">Tambah Data Muzakki</h2>
        <form action="createmuzaki.php" method="post" name="form2">
            <div class="form-group">
                <label for="id_muzaki">ID Muzaki:</label>
                <!-- <input type="number" class="form-control" id="id_amil" name="id_amil" required> -->
                <input type="text" class="form-control" name="id_muzaki" value="auto" id="id_muzaki" required>
            </div>

            <div class="form-group">
                <label for="nama_muzaki">Nama:</label>
                <input type="text" class="form-control" id="nama_muzaki" name="nama_muzaki" required>
            </div>

            <div class="form-group">
                <label for="jenis_zakat">Jenis Zakat:</label>
                <!-- <input type="option" class="form-control" id="jenis_zakat" name="jenis_zakat" required> -->
                <select class="form-control" id="jenis_zakat" name="jenis_zakat" required>
                    <option >  Jenis Zakat  </option>
                    <option value="Zakat Fitrah">Zakat Fitrah</option>
                    <option value="Zakat Mal">Zakat Mal</option>
                </select>
            </div>

            <div class="form-group">
                <label for="jumlah_zakat">Keluarga Yang Di Zakati:</label>
                <input type="text" class="form-control" id="jumlah_zakat" name="jumlah_zakat" required>
            </div>

            <button type="submit" class="btn btn-success w-100" name="Submit">Tambah</button>
            <br>
        </form>
    </div>
</body>
</html>

<?php
// Memanggil file koneksi.php
include_once("../koneksi.php");

// Perkondisian untuk mengecek apakah tombol submit sudah ditekan.
if (isset($_POST['Submit'])) {
    $id_muzaki = isset($_POST['id_muzaki']) && !empty($_POST['id_muzaki']) && $_POST['id_muzaki'] != 'auto' ? $_POST['id_muzaki'] : NULL;
    // Variable untuk menampung data $_POST yang dikirimkan melalui form.
    // $id = $_POST['id_amil'];
    $nama_muzaki = $_POST['nama_muzaki'];
    $jenis_zakat = $_POST['jenis_zakat'];
    $jumlah_zakat = $_POST['jumlah_zakat'];

    // Syntax untuk menambahkan data ke table mahasiswa
    $result1 = mysqli_query($con, "INSERT INTO muzaki(id_muzaki, nama_muzaki, jenis_zakat, jumlah_zakat) VALUES('$id_muzaki', '$nama_muzaki', '$jenis_zakat', '$jumlah_zakat')");

    // Menampilkan pesan jika data berhasil disimpan.
    echo '<br><br><div class="container">';
    echo '<div class="alert alert-success text-center">';
    echo "Data berhasil disimpan. <a href='readmuzaki.php'><strong>LIHAT DATA</strong></a>";
    echo '</div>';
    echo '</div>';
    //exit();
}

?>