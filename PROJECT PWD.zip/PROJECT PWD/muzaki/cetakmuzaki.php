<?php
require('../fpdf/fpdf.php');
include '../koneksi.php';

class PDF extends FPDF
{
    // ...
    function Header()
    {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, 'LAPORAN ZAKAT MUZAKI MASJID NURUL HUDA DAN TOTAL ZAKAT FITRAH', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(0, 10, 'LEMBAGA MIKRO PENGELOLAAN ZAKAT MASJID NURUL HUDA', 0, 1, 'C');
        $this->Ln(10);
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(30, 7, 'ID', 1, 0);
        $this->Cell(80,7, 'NAMA MUZAKI', 1, 0);
        $this->Cell(45,7, 'JENIS', 1, 0);
        $this->Cell(40,7, 'JUMLAH', 1, 1);
    }

    function ChapterBody($data)
    {
        $this->SetFont('Arial', '', 10);

        foreach ($data as $row) {
            $this->Cell(30, 7, $row['id_muzaki'], 1, 0);
            $this->Cell(80,7, $row['nama_muzaki'], 1, 0);
            $this->Cell(45,7, $row['jenis_zakat'], 1, 0);
            $this->Cell(40,7, $row['berat'] . ' Kg', 1, 1);
        }
    }

    function TotalRow($total)
    {
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(155, 7, 'Total Zakat', 1, 0, 'R');
        $this->Cell(40, 7, $total . ' Kg', 1, 1, 'C');
    }
}

$pdf = new PDF();
$pdf->AddPage();

// Fetch data from the database
$result_muzaki = mysqli_query($con, "SELECT id_muzaki, nama_muzaki, jenis_zakat, jumlah_zakat*2.5 AS berat FROM muzaki");
$total_zakat_result = mysqli_query($con, "SELECT SUM(jumlah_zakat*2.5) AS total_zakat FROM muzaki");
$total_zakat_row = mysqli_fetch_assoc($total_zakat_result);
$total_zakat = $total_zakat_row['total_zakat'];

$data_muzaki = array();
while ($row = mysqli_fetch_array($result_muzaki)) {
    $data_muzaki[] = $row;
}
$filename = "laporan_zakat_muzaki.pdf";
header('Content-Disposition: attachment; filename="' . $filename . '"');
$pdf->ChapterBody($data_muzaki);
$pdf->TotalRow($total_zakat);

$pdf->Output();
?>
