<?php
// Memanggil file koneksi.php
include_once("../koneksi.php");

// Perkondisian untuk mengecek apakah tombol submit sudah ditekan.
if (isset($_POST['update'])) {
    $id_muzaki = $_POST['id_muzaki'];
    $nama_muzaki = $_POST['nama_muzaki'];
    $jenis_zakat = $_POST['jenis_zakat'];
    $jumlah_zakat = $_POST['jumlah_zakat'];

    // Syntax untuk mengupdate data user berdasarkan id
    $result1 = mysqli_query($con, "UPDATE muzaki SET nama_muzaki='$nama_muzaki', jenis_zakat='$jenis_zakat', jumlah_zakat='$jumlah_zakat' where id_muzaki ='$id_muzaki'");

    // Redirect ke readmuzaki.php
    header("Location: readmuzaki.php");
}
?>


<?php
// Mengambil id dari url
// jangan di ganti jika tidak ingin error
$id_muzaki = $_GET['id'];

// Syntax untuk mengambil data berdasarkan id
$result1 = mysqli_query($con, "SELECT * FROM muzaki WHERE id_muzaki='$id_muzaki'");
while ($user_data = mysqli_fetch_array($result1)) {
    $nama_muzaki = $user_data['nama_muzaki'];
    $jenis_zakat = $user_data['jenis_zakat'];
    $jumlah_zakat = $user_data['jumlah_zakat'];
}
?>


<!DOCTYPE html>
<html>

<head>
    <title>Edit Data Muzaki</title>
    <!-- Include Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.15/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
</head>

<body class="bg-gray-100">
    <!-- navbar -->
    <div>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="#">
          <i class="fas fa-mosque"></i> <!-- Ikon masjid -->
          <b>ZAKAT MASJID NURUL HUDA</b>
        </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#"> / MUZAKI / Lihat / Update</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>



    <div class="container mx-auto p-4">
        <a href="readmuzaki.php" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded inline-block mb-4">Home Data</a>
        
        <form name="edit_muzaki" method="post" action="edit_muzaki.php">
    <div class="bg-white p-4 rounded shadow">
        <div class="mb-4">
            <label class="block text-gray-700 text-sm font-bold mb-2" for="nama_muzaki">Nama Muzaki</label>
            <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" name="nama_muzaki" value="<?php echo $nama_muzaki; ?>">
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 text-sm font-bold mb-2" for="jenis_zakat">Jenis Zakat</label>
            <select class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" name="jenis_zakat">
                <option value="Zakat Fitrah" <?php if ($jenis_zakat == 'Zakat Fitrah') echo 'selected'; ?>>Zakat Fitrah</option>
                <option value="Zakat Mal" <?php if ($jenis_zakat == 'Zakat Mal') echo 'selected'; ?>>Zakat Mal</option>
            </select>
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 text-sm font-bold mb-2" for="jumlah_zakat">Jumlah Zakat</label>
            <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" name="jumlah_zakat" value="<?php echo $jumlah_zakat; ?>">
        </div>
        <!-- Tambahkan input hidden untuk mengirim id_muzaki -->
        <input type="hidden" name="id_muzaki" value="<?php echo $id_muzaki; ?>">
        <button class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full" type="submit" name="update">Update</button>
    </div>
</form>

    </div>
</body>

</html>