<?php
// Memanggil file koneksi.php
include_once("../koneksi.php");

// Syntax untuk mengambil semua data dari table mahasiswa
$result1 = mysqli_query($con, "SELECT * FROM muzaki");
$jumlah_zakat = mysqli_query($con, "SELECT SUM(jumlah_zakat) * 2.5 AS total_zakat FROM muzaki"); // Menghitung jumlah zakat

// Fetch hasil query jumlah zakat
$total_zakat_data = mysqli_fetch_assoc($jumlah_zakat);
$total_zakat = $total_zakat_data['total_zakat'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Utama</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Custom CSS for row colors -->
    <style>
     
        .even-row {
            background-color: #f2f2f2;
        }

        .odd-row {
            background-color: #ffffff;
        }
    </style>
</head>

<body>
    <!-- navbar -->
    <div>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="#">
          <i class="fas fa-mosque"></i> <!-- Ikon masjid -->
          <b>ZAKAT MASJID NURUL HUDA</b>
        </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#"> / MUZAKI / Catat Muzaki</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>


    <div class="container mt-4">
        <a href="createmuzaki.php" class="btn btn-primary "><strong>Tambah Data Baru</strong></a>
        <a href="Muzaki.php" class="btn btn-success "><strong>Kembali Home Muzaki</strong></a>
        <!-- <a href="caridata.php" class="btn btn-success ">Cari Data</a> -->
        <br><br>
        <table class="table table-bordered w-100 text-center">
            <thead>
                <tr class="bg-primary text-white">
                    <th>ID Muzaki</th>
                    <th>Nama Muzaki</th>
                    <th>Jenis Zakat</th>
                    <th>Jumlah Zakat</th>
                    <th>Kelola Data</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $row_number = 0; // Initialize row number variable
                while ($user_data = mysqli_fetch_array($result1)) {
                    $berat = $user_data['jumlah_zakat']*2.5;
                    // Alternate row colors
                    $row_class = ($row_number % 2 == 0) ? 'even-row' : 'odd-row';
                    echo "<tr class='$row_class'>";
                    echo "<td>" . $user_data['id_muzaki'] . "</td>";
                    echo "<td>" . $user_data['nama_muzaki'] . "</td>";
                    echo "<td>" . $user_data['jenis_zakat'] . "</td>";
                    echo "<td>" . $berat ." Kg" . "</td>";
                    echo "<td><a href='edit_muzaki.php?id=$user_data[id_muzaki]' class='btn btn-primary'>Update</a> <a href='deletemuzaki.php?id=$user_data[id_muzaki]' class='btn btn-danger'>Delete</a></td></tr>";
                    $row_number++; // Increment row number
                }
                echo "<tr class='total-row'>"; // Menambahkan kelas 'total-row'
                echo "<td colspan='3'><strong>Total Zakat</strong></td>";
                echo "<td colspan='2'><strong> <h5>" . $total_zakat . " Kg" . "</h5></strong></td>";
                echo "</tr>";          
                ?>
            </tbody>
        </table>
    <a href="cetakmuzaki.php" class="btn btn-info text-white w-100"><strong>Cetak Data Menjadi PDF</strong></a>
    </div>
    

    <!-- Include Bootstrap JS and jQuery (optional) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
