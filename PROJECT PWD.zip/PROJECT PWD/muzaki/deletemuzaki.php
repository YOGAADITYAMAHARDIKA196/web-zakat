<?php
// mengambil file koneksi.php
include_once("../koneksi.php");

// mengambil id dari url
$id_muzaki = $_GET['id'];

// Syntax untuk menghapus data berdasarkan id
$result1 = mysqli_query($con, "DELETE FROM muzaki where id_muzaki ='$id_muzaki'");

// Setelah berhasil dihapus redirect ke index.php
header("Location:readmuzaki.php");
